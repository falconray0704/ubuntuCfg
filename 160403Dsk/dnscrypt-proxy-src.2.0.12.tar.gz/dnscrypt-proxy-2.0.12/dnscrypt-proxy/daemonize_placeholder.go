// +build !linux

package main

func Daemonize() {
}
