// +build !openbsd

package main

func Pledge() {

}

func PledgeChild() {

}
